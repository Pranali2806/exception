package com.cg.service;

import java.util.NoSuchElementException;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Album;
import com.cg.repo.AlbumRepo;

@Service
public class AlbumServiceImpl implements AlbumService {
	private EntityManager em;

	@Autowired
	AlbumRepo repo;

	public Album saveAlbum(Album album) {
		return repo.save(album);
	}

	public Album getAlbum(int id) throws NoSuchElementException{
		try {
			return repo.findById(id).get();
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No Album found for this id :" +id);
		}
	}



	public String deleteAlbum(int id) {
		Album album = repo.findById(id).get();
		repo.delete(album);
		return "Album Deleted";
	}

	@Override
	public Iterable<Album> getAll() {

		return repo.findAll();
	}

	@Override
	public Album updateAlbum(int id, Album a) {
		a.setId(id);
		repo.save(a);
		return a;
	}
}
