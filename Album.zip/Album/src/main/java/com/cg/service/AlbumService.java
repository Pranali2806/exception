package com.cg.service;

import com.cg.entity.Album;

public interface AlbumService {

	Album saveAlbum(Album album);

	Album getAlbum(int id);

	Album updateAlbum(int id, Album a);

	String deleteAlbum(int id);

	Iterable<Album> getAll();

}
